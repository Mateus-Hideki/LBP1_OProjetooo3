from flask import render_template, request, redirect, url_for, session
from models.model_login import User

def login_page():
    return render_template('index.html')

def login_action():
    username = request.form['username']
    password = request.form['password']

    user = User.authenticate(username, password)
    
    if user:
        session['user'] = username
        return redirect(url_for('dashboard'))
    else:
        return "Usuário ou senha incorretos"