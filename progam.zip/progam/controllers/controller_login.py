from flask import Blueprint, request, redirect, url_for, session, render_template
from models.model_login import User

login_controller = Blueprint ('login', __name__)

@login_controller('/')
def index():
    if 'username' in session:
          return f'Bem-vindo, {session["username"]}!'
    return 'Você não está logado!'

@login_controller.route('/login', methods = ['POST', 'GET'])
def login_page():
        return render_template('index.html')

def login_action():
    username = request.form['username']
    password = request.form['password']

    user = User.authenticate(username, password)
    
    if user:
        session['user'] = username
        return redirect(url_for('dashboard'))
    else:
        return "Usuário ou senha incorretos"
    
@login_controller.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))