class User:

    users_db = {
        'admin': '12345',
        'user1': 'password'
    }

    @classmethod
    def authenticate(cls, username, password):
        if username in cls.users_db and cls.users_db[username] == password:
            return True
        return False