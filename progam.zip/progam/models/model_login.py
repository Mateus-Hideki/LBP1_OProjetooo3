class User:
    def __init__(self, user, password):
        self.user = user
        self.password = password

    users = {
        'admin': '12345',
        'user1': 'password'
    }