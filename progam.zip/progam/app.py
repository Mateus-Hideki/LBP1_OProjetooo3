from flask import Flask
from controllers.controller_login import login_page, login_action

app = Flask(__name__)
app.secret_key = 'chave_secreta'

# Rotas
app.add_url_rule('/', view_func=login_page, methods=['GET'])
app.add_url_rule('/login', view_func=login_action, methods=['POST'])

if __name__ == '__main__':
    app.run(debug=True)