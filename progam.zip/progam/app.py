from flask import Flask
from controllers.controller_login import login_controller

app = Flask(__name__)
app.register_blueprint(login_controller)
app.secret_key = 'chave_secreta'

if __name__ == '__main__':
    app.run(debug=True)