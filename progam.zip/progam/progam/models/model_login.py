class User:
    users = {
        'admin': '12345',
        'user1': 'password'
    }

    @classmethod
    def authenticate(cls, username, password):
        if username in cls.users and cls.users[username] == password:
            return True
        return False