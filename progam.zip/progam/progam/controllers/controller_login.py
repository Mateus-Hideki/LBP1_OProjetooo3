from flask import Blueprint, request, redirect, url_for, session, render_template
from models.model_login import User

login_controller = Blueprint('login', __name__)

@login_controller.before_request
def check_session():
    protected_routes = ['login.page']
    if request.endpoint in protected_routes and 'username' not in session:
        return redirect(url_for('login.index', message='Você precisa estar logado para acessar essa página.'))

@login_controller.route('/login', methods=['GET'])
def index():
    message = request.args.get('message', '')
    if 'username' in session:
        return redirect(url_for('login.page'))
    return render_template('index.html', message=message)

@login_controller.route('/login', methods=['POST'])
def login_action():
    username = request.form.get('username')
    password = request.form.get('password')

    if not username or not password:
        return render_template('index.html', message='Usuário e senha são obrigatórios')

    user = User.authenticate(username, password)

    if user:
        session['username'] = username
        return redirect(url_for('login.page'))
    else:
        return render_template('index.html', message="Usuário ou senha incorretos")

@login_controller.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login.index', message='Você foi desconectado.'))

@login_controller.route('/page')
def page():
    if 'username' in session:
        return render_template('page.html', username=session['username'])
    return redirect(url_for('login.index'))