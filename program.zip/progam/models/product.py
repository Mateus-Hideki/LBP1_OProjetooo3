class Product:
    def __init__(self, id, name, price):
        self.id = id
        self.name = name
        self.price = price

# Lista de produtos disponíveis
products = [
    Product(1, "Maçã", 1.50),
    Product(2, "Banana", 1.20),
    Product(3, "Laranja", 1.80),
    Product(4, "Uva", 2.00),
    Product(5, "Pera", 2.50),
    Product(6, "Melancia", 5.00)
]
