class User:
    def __init__(self, id, name, password, type):
        self.id = id
        self.name = name
        self.password = password
        self.type = type
       
listUsers = []
listUsers.append(User(1, "Adm", "123456789", "admin")) 
listUsers.append(User(2, "Padrao", "987654321", "std"))