from flask import Flask, render_template
from controllers.controller_login import login_controller
from controllers.controller_cart import cart_controller

app = Flask(__name__)
app.register_blueprint(login_controller)
app.register_blueprint(cart_controller)
app.secret_key = 'chave_secreta'

@app.errorhandler(404)
def pageNotFound(e):
    return render_template("404.html"), 404

@app.errorhandler(403)
def pageNotFound(e):
    return render_template("403.html"), 403

@app.errorhandler(401)
def pageNotFound(e):
    return render_template("401.html"), 401

@app.errorhandler(500)
def pageNotFound(e):
    return render_template("500.html"), 500

if __name__ == '__main__':
    app.run(debug=True)