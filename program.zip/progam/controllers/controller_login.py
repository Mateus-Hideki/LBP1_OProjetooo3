from flask import Blueprint, request, redirect, url_for, session, render_template, flash, make_response
from models.model_login import listUsers

login_controller = Blueprint('login', __name__)

@login_controller.before_request
def check_session():
    protected_routes = ['login.page']
    if request.endpoint in protected_routes and 'username' not in session:
        return redirect(url_for('login.index', message='Você precisa estar logado para acessar essa página.'))

@login_controller.route('/login', methods=['GET'])
def index():
    message = request.args.get('message', '')
    if 'username' in session:
        return redirect(url_for('login.page'))
    
    username_cookie = request.cookies.get('username')
    user_id_cookie = request.cookies.get('user_id')
    user_type_cookie = request.cookies.get('user_type')

    if username_cookie and user_id_cookie and user_type_cookie:
        session['username'] = username_cookie
        session['user_id'] = user_id_cookie
        session['user_type'] = user_type_cookie
        return redirect(url_for('login.page'))
    
    return render_template('index.html', message=message)

@login_controller.route('/login', methods=['POST'])
def login_action():
    username = request.form.get('username')
    password = request.form.get('password')

    if not username or not password:
        return render_template('index.html', message='Usuário e senha são obrigatórios')
    
    for usuario in listUsers:
        if usuario.name == username:
            if usuario.password == password:
                session["id"] = usuario.id
                session["type"] = usuario.type
                session["username"] = usuario.name 
                flash("Bem vindo!", "success")
                response = make_response(redirect(url_for("login.page")))
                response.set_cookie('username', username, max_age=60*60*24*7)
                response.set_cookie('user_id', str(usuario.id), max_age=60*60*24*7)
                response.set_cookie('user_type', usuario.type, max_age=60*60*24*7)
            
            else:
                flash("Senha incorreta.", "invalid")
                return redirect(url_for("login.index"))
    
    flash("Usuário não encontrado.", "invalid")
    return redirect(url_for("login.index"))

@login_controller.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('id', None)
    session.pop('type', None)
    return redirect(url_for('login.index', message='Você foi desconectado.'))

@login_controller.route('/page')
def page():
    if 'username' in session:
        return render_template('page.html', username=session['username'])
    return redirect(url_for('login.index'))