import json
from flask import Blueprint, render_template, redirect, url_for, request, make_response, flash
from models.product import products

cart_controller = Blueprint('cart', __name__)

def get_cart_from_cookies():
    cart_cookie = request.cookies.get('cart')
    if cart_cookie:
        return json.loads(cart_cookie)
    return {}

def save_cart_to_cookies(cart):
    response = make_response(redirect(url_for('cart.cart')))
    response.set_cookie('cart', json.dumps(cart), max_age=60*60*24*7)
    return response

@cart_controller.route('/produtos')
def products_page():
    return render_template("products.html", items=products)

@cart_controller.route('/carrinho')
def cart():
    cart = get_cart_from_cookies()
    total = sum(item.price * quantity for item_id, quantity in cart.items() for item in products if item.id == int(item_id))
    cart_items = [{"item": next(item for item in products if item.id == int(item_id)), "quantity": quantity} for item_id, quantity in cart.items()]
    return render_template("cart.html", cart_items=cart_items, total=total)

@cart_controller.route('/add/<int:item_id>')
def add_to_cart(item_id):
    cart = get_cart_from_cookies()
    cart[str(item_id)] = cart.get(str(item_id), 0) + 1
    flash("Item adicionado ao carrinho!", "success")
    return save_cart_to_cookies(cart)

@cart_controller.route('/remove/<int:item_id>')
def remove_from_cart(item_id):
    cart = get_cart_from_cookies()
    if str(item_id) in cart:
        if cart[str(item_id)] > 1:
            cart[str(item_id)] -= 1
        else:
            del cart[str(item_id)]
        flash("Item removido do carrinho!", "success")
    else:
        flash("Item não encontrado no carrinho.", "warning")
    return save_cart_to_cookies(cart)