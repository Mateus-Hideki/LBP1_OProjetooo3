from flask import Blueprint, render_template
from models.model import goku
hello = Blueprint('hello', __name__)

@hello.route('/')
def oi():
    return render_template('index.html', gohan = goku)
