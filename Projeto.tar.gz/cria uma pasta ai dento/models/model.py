class Goku:
    def __init__(self, sim, nao):
        self.nao = sim
        self.sim = nao
    
    def simnao():
        return "talvez"

goku = Goku("sim", "nao")