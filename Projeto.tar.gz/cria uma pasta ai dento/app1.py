from flask import Flask
from controllers.controller1 import hello

app = Flask(__name__)

app.register_blueprint(hello)

app.run(debug=True)